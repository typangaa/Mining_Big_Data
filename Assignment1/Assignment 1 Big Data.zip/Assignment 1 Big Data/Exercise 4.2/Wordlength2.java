package edu.stanford.cs246.Wordlength2;


import java.io.IOException;
import java.util.Arrays;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;


public class Wordlength2 extends Configured implements Tool {
   public static void main(String[] args) throws Exception {
      System.out.println(Arrays.toString(args));
      int res = ToolRunner.run(new Configuration(), new Wordlength2(), args);
      
      System.exit(res);
   }

   @Override
   public int run(String[] args) throws Exception {
      //System.out.println(Arrays.toString(args));
	   String intermediate_file_path = "intermediate_output2/part-r-00000";
	   
	   Configuration conf_1 = this.getConf();
	      
	   Job job1 = Job.getInstance(conf_1, "Wordlength2_1");
	   job1.setJarByClass(Wordlength2.class);
	   job1.setOutputKeyClass(Text.class);
	   job1.setOutputValueClass(IntWritable.class);

	   job1.setMapperClass(Map_1.class);
	   job1.setReducerClass(Reduce_1.class);

	   job1.setInputFormatClass(TextInputFormat.class);
	   job1.setOutputFormatClass(TextOutputFormat.class);

	   FileInputFormat.addInputPath(job1, new Path(args[0]));
	   FileOutputFormat.setOutputPath(job1, new Path(intermediate_file_path));
	   job1.waitForCompletion(true);
      

	   Configuration conf_2 = this.getConf();
	   Job job2 = Job.getInstance(conf_2, "Wordlength2_2");
	      
	   job2.setJarByClass(Wordlength2.class);
	   job2.setOutputKeyClass(Text.class);
	   job2.setOutputValueClass(IntWritable.class);

	   job2.setMapperClass(Map_2.class);
	   job2.setReducerClass(Reduce_2.class);

	   job2.setInputFormatClass(TextInputFormat.class);
	   job2.setOutputFormatClass(TextOutputFormat.class);
	
	     
	   FileInputFormat.addInputPath(job2, new Path(intermediate_file_path));
	   FileOutputFormat.setOutputPath(job2, new Path(args[1]));
	   job2.waitForCompletion(true);
	   return 0;
   }
   
   public static class Map_1 extends Mapper<LongWritable, Text, Text, IntWritable> {
      private final static IntWritable ONE = new IntWritable(1);
      private Text word = new Text();

      @Override
      public void map(LongWritable key, Text value, Context context)
              throws IOException, InterruptedException {
          String line = value.toString().toLowerCase().replaceAll("\\p{Punct}", "");;
          StringTokenizer tokenizer = new StringTokenizer(line);
          while(tokenizer.hasMoreTokens()){
         	 word.set(tokenizer.nextToken());
         	 context.write(word,  ONE);
         }
         
         
      }
   }

   public static class Reduce_1 extends Reducer<Text, IntWritable, Text, IntWritable> {
     
	  private final static IntWritable ONE = new IntWritable(1);
	   @Override
      public void reduce(Text key, Iterable<IntWritable> values, Context context)
              throws IOException, InterruptedException {
        
         context.write(key, ONE);
      }
   }
   
   public static class Map_2 extends Mapper<LongWritable, Text, Text, IntWritable> {
	      private final static IntWritable ONE = new IntWritable(1);
	      //private Text word = new Text();

	      @Override
	      public void map(LongWritable key, Text value, Context context)
	              throws IOException, InterruptedException {
	         
	    	  
	    	  String key_value[] = value.toString().split("\t");
	    	  
	          String key_length = Integer.toString(key_value[0].length());
	          
	          context.write(new Text(key_length), ONE);
	         }
	      
	   }

	   public static class Reduce_2 extends Reducer<Text, IntWritable, Text, IntWritable> {
	      @Override
	      public void reduce(Text key, Iterable<IntWritable> values, Context context)
	              throws IOException, InterruptedException {
	         int sum = 0;
	         for (IntWritable val : values) {
	            sum += val.get();
	         }
	         context.write(key, new IntWritable(sum));
	      }
	   }
}