Name: Tak Yin Pang
Student ID: a1796036
Email: a1796036@student.adelaide.edu.au

Instruction to run code 

Exercise 1:
Execute the below. 

Python3 Ex1.py 

Exercise 2:
Execute the below. 

Python3 Ex2.py 